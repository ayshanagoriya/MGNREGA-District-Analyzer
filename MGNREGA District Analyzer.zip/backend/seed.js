// backend/seed.js
const { sequelize, District } = require('./models');

async function seed() {
  try {
    await sequelize.sync({ force: true }); // drops & recreates tables
    console.log('✅ Database synced (tables recreated)');

    const districts = [
      "AGRA", "ALIGARH", "AMBEDKAR NAGAR", "AMETHI", "AMROHA", "AURAIYA", "AYODHYA", "AZAMGARH",
      "BAGHPAT", "BAHRAICH", "BALLIA", "BALRAMPUR", "BANDA", "BARABANKI", "BAREILLY", "BASTI",
      "BIJNOR", "BUDAUN", "BULANDSHAHR", "CHANDAULI", "CHITRAKOOT", "DEORIA", "ETAH", "ETAWAH",
      "FARRUKHABAD", "FATEHPUR", "FIROZABAD", "GAUTAM BUDDHA NAGAR", "GHAZIABAD", "GHAZIPUR",
      "GONDA", "GORAKHPUR", "HAMIRPUR", "HAPUR", "HARDOI", "HATHRAS", "JALAUN", "JAUNPUR",
      "JHANSI", "KANNAUJ", "KANPUR DEHAT", "KANPUR NAGAR", "KASHGANJ", "KAUSHAMBI", "KHERI",
      "KUSHI NAGAR", "LALITPUR", "LUCKNOW", "MAHARAJGANJ", "MAHOBA", "MAINPURI", "MATHURA",
      "MAU", "MEERUT", "MIRZAPUR", "MORADABAD", "MUZAFFARNAGAR", "PILIBHIT", "PRATAPGARH",
      "PRAYAGRAJ", "RAE BARELI", "RAMPUR", "SAHARANPUR", "SAMBHAL", "SANT KABEER NAGAR",
      "SANT RAVIDAS NAGAR", "SHAHJAHANPUR", "SHAMLI", "SHRAVASTI", "SIDDHARTH NAGAR",
      "SITAPUR", "SONBHADRA", "SULTANPUR", "UNNAO", "VARANASI"
    ];

    const records = districts.map((name, index) => ({
      state: 'Uttar Pradesh',
      district_code: (3100 + index).toString(), // generates unique codes like 3100, 3101, etc.
      name
    }));

    await District.bulkCreate(records);
    console.log(`✅ Seeded ${records.length} districts successfully!`);

    process.exit(0);
  } catch (error) {
    console.error('❌ Error while seeding:', error);
    process.exit(1);
  }
}

seed();
