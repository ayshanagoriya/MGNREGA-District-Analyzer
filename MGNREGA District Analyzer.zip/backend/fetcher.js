// fetcher.js — one-shot or scheduled fetcher for MGNREGA district performance

require('dotenv').config();
const axios = require('axios');
const { sequelize, District, Report } = require('./models');
const sleep = ms => new Promise(r => setTimeout(r, ms));

// -----------------------------------------------
// CONFIGURATION SECTION
// -----------------------------------------------

// Change this if you want data for another state
const STATE_NAME = 'UTTAR PRADESH';

// Base API endpoint for data.gov.in
const API_BASE = 'https://api.data.gov.in/resource';

// ✅ Resource ID for “District-wise MGNREGA Data at a Glance”
const RESOURCE_ID = 'ee03643a-ee4c-48c2-ac30-9f2ff26ab722';

// ✅ Your API Key (from .env file)
const API_KEY = process.env.DATA_GOV_API_KEY || '';

if (!API_KEY) {
  console.warn('⚠️ Missing API key! Please set DATA_GOV_API_KEY in .env file.');
}

// -----------------------------------------------
// INITIALIZE DATABASE
// -----------------------------------------------
async function init() {
  await sequelize.sync();
  console.log('✅ Database synced successfully');
}

// -----------------------------------------------
// FETCH AND STORE DATA
// -----------------------------------------------
async function fetchDistrictsAndReports() {
  let page = 1;
  const limit = 100;
  let totalFetched = 0;

  while (true) {
    // ✅ Construct API URL
    const url = `${API_BASE}/${RESOURCE_ID}?format=json&limit=${limit}&offset=${(page - 1) * limit}&api-key=${API_KEY}`;

    try {
      const resp = await axios.get(url);
      const records = resp.data.records || [];

      if (!records.length) {
        console.log('No more records to fetch.');
        break;
      }

      // ✅ Filter by Uttar Pradesh (correct key: state_name)
      const filteredRecords = records.filter(
        r => r.state_name && r.state_name.toUpperCase() === STATE_NAME
      );

      for (const row of filteredRecords) {
        const districtName = row.district_name || 'UNKNOWN';
        const districtCode = (row.district_code || districtName).toString();

        // ✅ Upsert district
        await District.upsert({
          state: STATE_NAME,
          district_code: districtCode,
          name: districtName,
        });

        // ✅ Extract report data (matching dataset fields)
        const year = parseInt(row.fin_year?.split('-')[0]) || new Date().getFullYear();
        const month = row.month || 'NA';
        const workers = parseInt(row.Total_No_of_Workers || 0);
        const persondays = parseInt(row.Persondays_of_Central_Liability_so_far || 0);
        const wages = parseFloat(row.Wages || 0);

        // ✅ Store report
        await Report.create({
          district_code: districtCode,
          year,
          month,
          workers,
          persondays,
          wages,
          raw_json: JSON.stringify(row),
        });
      }

      totalFetched += filteredRecords.length;
      console.log(`✅ Fetched ${filteredRecords.length} records (Total: ${totalFetched})`);

      // If fewer than 100 records, no more pages
      if (records.length < limit) break;

      page++;
      await sleep(200);
    } catch (err) {
      console.error('⚠️ Fetch error:', err.message);
      await sleep(2000);
    }
  }

  console.log(`✅ Finished fetching data. Total records saved: ${totalFetched}`);
}

// -----------------------------------------------
// MAIN ENTRY POINT
// -----------------------------------------------
if (require.main === module) {
  (async () => {
    await init();
    await fetchDistrictsAndReports();
    process.exit(0);
  })();
}

module.exports = { fetchDistrictsAndReports };
