// backend/models.js
const { Sequelize, DataTypes } = require('sequelize');

// Initialize SQLite database
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './db.sqlite', // Database file created in the backend folder
  logging: false          // Set to true if you want SQL logs
});

// Define District model
const District = sequelize.define('District', {
  state: {
    type: DataTypes.STRING,
    allowNull: false
  },
  district_code: {
    type: DataTypes.STRING,
    unique: true
  },
  name: {
    type: DataTypes.STRING
  }
});

// Define Report model
const Report = sequelize.define('Report', {
  district_code: {
    type: DataTypes.STRING
  },
  year: {
    type: DataTypes.INTEGER
  },
  month: {
    type: DataTypes.INTEGER
  },
  workers: {
    type: DataTypes.INTEGER
  },
  persondays: {
    type: DataTypes.INTEGER
  },
  wages: {
    type: DataTypes.FLOAT
  },
  raw_json: {
    type: DataTypes.TEXT
  }
});

// Export all models and sequelize instance
module.exports = { sequelize, District, Report };
