const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const { sequelize, District, Report } = require('./models');

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Health check endpoint
app.get('/health', (req, res) => res.json({ ok: true }));

// ✅ Get all districts
app.get('/districts', async (req, res) => {
  try {
    const districts = await District.findAll({ order: [['name', 'ASC']] });
    res.json(districts.map(d => ({ code: d.district_code, name: d.name })));
  } catch (error) {
    console.error('Error fetching districts:', error);
    res.status(500).json({ error: 'Failed to fetch districts' });
  }
});

// ✅ Get reports for a district
// Example: /reports?district=AP001&years=2023,2024
app.get('/reports', async (req, res) => {
  try {
    const district = req.query.district;
    if (!district) return res.status(400).json({ error: 'district required' });

    const rows = await Report.findAll({
      where: { district_code: district },
      order: [['year', 'ASC'], ['month', 'ASC']],
    });

    res.json(rows);
  } catch (error) {
    console.error('Error fetching reports:', error);
    res.status(500).json({ error: 'Failed to fetch reports' });
  }
});

// ✅ Get latest metrics for a district
// Example: /latest/AP001
app.get('/latest/:district', async (req, res) => {
  try {
    const district = req.params.district;
    const row = await Report.findOne({
      where: { district_code: district },
      order: [['year', 'DESC'], ['month', 'DESC']],
    });

    if (!row) return res.status(404).json({ error: 'not found' });
    res.json(row);
  } catch (error) {
    console.error('Error fetching latest report:', error);
    res.status(500).json({ error: 'Failed to fetch latest report' });
  }
});

// ✅ Serve frontend (React build)
const frontendPath = path.join(__dirname, 'frontend', 'dist');
app.use(express.static(frontendPath));

// For any route not handled by API, return the frontend index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// ✅ Start the server
async function start() {
  try {
    await sequelize.sync();
    app.listen(PORT, () => console.log(`✅ Server started on port ${PORT}`));
  } catch (error) {
    console.error('❌ Failed to start server:', error);
  }
}

start();
