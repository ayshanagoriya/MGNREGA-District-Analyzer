import React from 'react'


export default function DistrictSelector({districts, onSelect}){
return (
<div className="card">
<h2>Choose your district / अपने जिले का चुनाव करें</h2>
<select onChange={e=>onSelect(e.target.value)} defaultValue="">
<option value="">-- Select district --</option>
{districts.map(d=> <option key={d.code} value={d.code}>{d.name}</option>)}
</select>
</div>
)
}