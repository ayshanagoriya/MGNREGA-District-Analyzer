import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [districts, setDistricts] = useState([]);

  useEffect(() => {
    console.log("Fetching data from backend...");
    axios.get("http://localhost:4000/districts")
      .then(res => {
        console.log("District data fetched:", res.data);
        setDistricts(res.data);
      })
      .catch(err => console.error("Error fetching:", err));
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h1>UP Districts</h1>
      <p>Total: {districts.length}</p>
      {districts.length > 0 ? (
        <ul>
          {districts.map((d) => (
            <li key={d.code}>{d.name}</li>
          ))}
        </ul>
      ) : (
        <p>Loading districts...</p>
      )}
    </div>
  );
}

export default App;
